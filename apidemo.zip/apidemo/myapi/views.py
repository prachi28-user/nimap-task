from django.shortcuts import render
from rest_framework import viewsets,generics
from .serializers import ClientSerializer,ProjectSerializer
from .models import Client,Project
# Create your views here.

class ClientViewSet(viewsets.ModelViewSet):
    queryset = Client.objects.all().order_by('companyName')
    serializer_class = ClientSerializer

class ProjectCreateView(generics.CreateAPIView):
    queryset = Project.objects.all()
    serializer_class = ProjectSerializer

class ProjectListView(generics.ListAPIView):
    queryset = Project.objects.all()
    serializer_class = ProjectSerializer